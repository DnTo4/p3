/**
 * 
 */
/**
 * 
 */
module practica2 {
	requires java.sql;
}